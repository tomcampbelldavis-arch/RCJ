# RCJ.ExhibitVerifier_Clerk.ps1
# Patched: suppress modal message boxes, robust logging, SignedCms first, OpenSSL fallback with safe argument handling.
# Build with: ps2exe -inputFile .\RCJ.ExhibitVerifier_Clerk.ps1 -outputFile .\RCJ.ExhibitVerifier_Clerk.exe -noConsole -sta

# -------------------------
# Early file logging (always on)
# -------------------------
$LogFile = Join-Path $env:TEMP 'RCJ-ExhibitVerifier.log'
function FileLog { param([string]$t) try { $ts=(Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff"); [System.IO.File]::AppendAllText($LogFile, "$ts  $t`r`n") } catch {} }
FileLog "=== RCJ.ExhibitVerifier starting (PID $([System.Diagnostics.Process]::GetCurrentProcess().Id)) ==="

# -------------------------
# Make non-terminating errors throw so we can catch them
# -------------------------
$ErrorActionPreference = 'Stop'

# -------------------------
# Helper: safe Add-Type by name (log failures, don't throw modal dialogs)
# -------------------------
function Safe-AddType {
    param([string]$assemblyName)
    try {
        Add-Type -AssemblyName $assemblyName -ErrorAction Stop
        FileLog ("Loaded assembly: {0}" -f $assemblyName)
        return $true
    } catch {
        $msg = "Add-Type failed for {0}: {1}: {2}" -f $assemblyName, $_.Exception.GetType().FullName, $_.Exception.Message
        FileLog $msg
        return $false
    }
}

# -------------------------
# Install AppDomain and Dispatcher handlers early to prevent modal dialogs
# -------------------------
try {
    [AppDomain]::CurrentDomain.UnhandledException.Add(
        [UnhandledExceptionEventHandler]{
            param($s,$a)
            try {
                $ex = $a.ExceptionObject
                if ($ex -is [System.Exception]) {
                    FileLog ("UnhandledDomainException: {0}: {1}" -f $ex.GetType().FullName, $ex.Message)
                    FileLog $ex.StackTrace
                } else {
                    FileLog ("UnhandledDomainException (non-exception): {0}" -f $ex)
                }
            } catch {}
        }
    )
} catch {
    FileLog ("Failed to register AppDomain handler: {0}" -f $_.Exception.Message)
}

# Try to load WPF assemblies safely (log failures instead of letting them throw modal dialogs)
$pf = Safe-AddType 'PresentationFramework'
$pc = Safe-AddType 'PresentationCore'
$wb = Safe-AddType 'WindowsBase'
$sx = Safe-AddType 'System.Xaml'

# If PresentationFramework failed, we still continue but GUI won't work; log and exit gracefully.
if (-not $pf) {
    FileLog "PresentationFramework not available; GUI cannot start. Exiting."
    exit 1
}

# Now that PresentationFramework is loaded, register Dispatcher handler to catch WPF exceptions
try {
    [System.Windows.Threading.Dispatcher]::CurrentDispatcher
    [System.Windows.Threading.Dispatcher]::UnhandledException.Add(
        [System.Windows.Threading.DispatcherUnhandledExceptionEventHandler]{
            param($sender,$args)
            try {
                $ex = $args.Exception
                FileLog ("Unhandled UI exception: {0}: {1}" -f $ex.GetType().FullName, $ex.Message)
                FileLog $ex.StackTrace
                try { if ($global:ReportBox) { $global:ReportBox.AppendText((Get-Date).ToString("u") + "  Unhandled UI exception: " + $ex.Message + "`r`n"); $global:ReportBox.ScrollToEnd() } } catch {}
            } catch {}
            $args.Handled = $true
        }
    )
} catch {
    FileLog ("Failed to register Dispatcher handler: {0}" -f $_.Exception.Message)
}

# -------------------------
# Load crypto assemblies safely
# -------------------------
$sec = Safe-AddType 'System.Security'
$sc  = Safe-AddType 'System.Security.Cryptography'
$pkcs = Safe-AddType 'System.Security.Cryptography.Pkcs'
$CanVerifyPkcs7 = $false
if ($pkcs) {
    try {
        if ([type]::GetType('System.Security.Cryptography.Pkcs.SignedCms', $false)) {
            $CanVerifyPkcs7 = $true
            FileLog "PKCS#7 APIs available."
        } else {
            FileLog "PKCS#7 assembly loaded but SignedCms type not found."
        }
    } catch {
        FileLog ("PKCS#7 detection error: {0}" -f $_.Exception.Message)
    }
} else {
    FileLog "PKCS#7 not available; signature checks will be skipped."
}

# -------------------------
# Provide a no-op MessageBox replacement (in case other code calls MessageBox.Show)
# -------------------------
function Show-UserMessage {
    param([string]$text, [string]$caption = "")
    FileLog ("UserMessage [{0}]: {1}" -f $caption, $text)
    try {
        if ($global:ReportBox) { $global:ReportBox.AppendText((Get-Date).ToString("u") + "  " + $caption + " " + $text + "`r`n"); $global:ReportBox.ScrollToEnd() }
    } catch {}
    return 'OK'
}

# -------------------------
# XAML UI (unchanged layout)
# -------------------------
$xaml = @"
<Window
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    Title="RCJ Exhibit Verifier"
    Height="420" Width="720"
    WindowStartupLocation="CenterScreen">
  <Grid Margin="12">
    <Grid.RowDefinitions>
      <RowDefinition Height="Auto"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="Auto"/>
    </Grid.RowDefinitions>

    <StackPanel Orientation="Horizontal" Grid.Row="0" Margin="0,0,0,8">
      <TextBox Name="FolderBox" Width="520" Height="28" Margin="0,0,8,0" />
      <Button Name="BtnBrowse" Content="Browse" Width="90" Height="28" Margin="0,0,8,0"/>
      <Button Name="BtnVerify" Content="Verify Exhibit" Width="120" Height="28"/>
    </StackPanel>

    <TextBox Name="ReportBox"
             Grid.Row="1"
             IsReadOnly="True"
             TextWrapping="Wrap"
             VerticalScrollBarVisibility="Auto"
             AcceptsReturn="True"
             FontFamily="Consolas"
             FontSize="12"/>

    <StackPanel Orientation="Horizontal" Grid.Row="2" HorizontalAlignment="Right" Margin="0,8,0,0">
      <Button Name="BtnCopyEmail" Content="Copy Email" Width="110" Height="34" Margin="0,0,8,0"/>
      <Button Name="BtnOpenMail" Content="Open Mail Client" Width="140" Height="34" Margin="0,0,8,0"/>
      <Button Name="BtnClose" Content="Close" Width="90" Height="34"/>
    </StackPanel>
  </Grid>
</Window>
"@

# -------------------------
# Load XAML and controls (defensive)
# -------------------------
try {
    $reader  = New-Object System.Xml.XmlNodeReader ([xml]$xaml)
    $window  = [Windows.Markup.XamlReader]::Load($reader)
} catch {
    FileLog ("XAML load failed: {0}" -f $_.Exception.Message)
    Show-UserMessage ("Internal error loading UI. See log: $LogFile") "RCJ Verifier"
    exit 1
}

# Expose ReportBox globally for dispatcher handler to write into
$FolderBox    = $window.FindName('FolderBox')
$BtnBrowse    = $window.FindName('BtnBrowse')
$BtnVerify    = $window.FindName('BtnVerify')
$ReportBox    = $window.FindName('ReportBox')
$BtnCopyEmail = $window.FindName('BtnCopyEmail')
$BtnOpenMail  = $window.FindName('BtnOpenMail')
$BtnClose     = $window.FindName('BtnClose')
$global:ReportBox = $ReportBox

# Track COM object for folder picker so we can release it on close
$global:ShellCom = $null

# -------------------------
# UI logging helper (safe)
# -------------------------
function Write-Log {
    param([string]$Text)
    try {
        $ts = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd HH:mm:ssK")
        $ReportBox.AppendText("$ts  $Text`r`n")
        $ReportBox.ScrollToEnd()
    } catch {
        # UI may not be ready; still write to file
    }
    FileLog $Text
}

# -------------------------
# Crypto helpers (unchanged but defensive)
# -------------------------
function Get-Sha256 {
    param([string]$Path)
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Path)
        $sha   = [System.Security.Cryptography.SHA256]::Create()
        $hash  = $sha.ComputeHash($bytes)
        ($hash | ForEach-Object { $_.ToString("x2") }) -join ""
    } catch {
        Write-Log ("Error computing SHA256 for {0}: {1}" -f $Path, $_.Exception.Message)
        $null
    }
}

# -------------------------
# Robust PKCS#7 verification function (SignedCms first, OpenSSL fallback)
# -------------------------
function Test-Pkcs7Signature {
    param([string]$ContentPath, [string]$SignaturePath, [string]$OptionalSignerCertPath = $null)

    Write-Log ("Attempting PKCS#7 verification for Content='" + $ContentPath + "' Sig='" + $SignaturePath + "'")

    # 1) Try .NET SignedCms if available
    try {
        if ($CanVerifyPkcs7) {
            Write-Log "Trying .NET SignedCms verification..."
            try {
                [byte[]]$contentBytes = [System.IO.File]::ReadAllBytes($ContentPath)
                [byte[]]$sigBytes     = [System.IO.File]::ReadAllBytes($SignaturePath)
                $contentInfo = [System.Security.Cryptography.Pkcs.ContentInfo]::new($contentBytes)
                $cms         = [System.Security.Cryptography.Pkcs.SignedCms]::new($contentInfo, $true)
                $cms.Decode($sigBytes)
                # Validate chain. To accept self-signed, change to CheckSignature($false) and validate fingerprint separately.
                $cms.CheckSignature($true)
                Write-Log "SignedCms: signature OK"
                return $true
            } catch {
                Write-Log ("SignedCms verification failed: " + $_.Exception.Message)
                # fall through to openssl fallback
            }
        } else {
            Write-Log "SignedCms not available on this runtime."
        }
    } catch {
        Write-Log ("SignedCms attempt threw: " + $_.Exception.Message)
    }

    # 2) Fallback: try OpenSSL cms if available on PATH (safe argument array, suppress binary stdout)
    try {
        $openssl = "openssl"
        $opensslAvailable = $false
        try {
            & $openssl version > $null 2>&1
            if ($LASTEXITCODE -eq 0) { $opensslAvailable = $true }
        } catch { $opensslAvailable = $false }

        if (-not $opensslAvailable) {
            Write-Log "OpenSSL not found on PATH; cannot use fallback."
        } else {
            Write-Log "Trying OpenSSL cms fallback verification..."

            # DER attempt (write verified content to NUL to avoid binary in logs)
            $opensslArgs = @("cms","-verify","-in",$SignaturePath,"-inform","DER","-content",$ContentPath,"-out","NUL")
            if ($OptionalSignerCertPath -and (Test-Path $OptionalSignerCertPath)) {
                $opensslArgs += @("-CAfile",$OptionalSignerCertPath)
                Write-Log ("Using CAfile: " + $OptionalSignerCertPath)
            }
            $opensslArgs += "-binary"

            Write-Log ("Running OpenSSL (DER): " + $openssl + " " + ($opensslArgs -join ' '))
            $proc = $null
            try {
                $proc = Start-Process -FilePath $openssl -ArgumentList $opensslArgs -NoNewWindow -Wait -PassThru -RedirectStandardError stderr.txt -RedirectStandardOutput stdout.txt
            } catch {
                Write-Log ("Start-Process (DER) threw: " + $_.Exception.Message)
            }

            $stderr = ""
            $stdout = ""
            if (Test-Path stderr.txt) { $stderr = (Get-Content stderr.txt -Raw) -replace "`r","" }
            if (Test-Path stdout.txt) { $stdout = (Get-Content stdout.txt -Raw) -replace "`r","" }
            Write-Log ("OpenSSL stdout: " + ($stdout -replace "`n"," | "))
            Write-Log ("OpenSSL stderr: " + ($stderr -replace "`n"," | "))

            $exit1 = -1
            try { if ($proc -ne $null) { $exit1 = $proc.ExitCode } } catch {}

            if ($exit1 -eq 0) {
                Write-Log "OpenSSL cms verification succeeded (DER)."
                Remove-Item stderr.txt, stdout.txt -ErrorAction SilentlyContinue
                return $true
            }

            # PEM attempt (suppress binary output)
            Write-Log "OpenSSL DER verify failed; trying PEM form..."
            $opensslArgsPem = @("cms","-verify","-in",$SignaturePath,"-inform","PEM","-content",$ContentPath,"-out","NUL")
            if ($OptionalSignerCertPath -and (Test-Path $OptionalSignerCertPath)) {
                $opensslArgsPem += @("-CAfile",$OptionalSignerCertPath)
            }
            $opensslArgsPem += "-binary"

            Write-Log ("Running OpenSSL (PEM): " + $openssl + " " + ($opensslArgsPem -join ' '))
            $proc2 = $null
            try {
                $proc2 = Start-Process -FilePath $openssl -ArgumentList $opensslArgsPem -NoNewWindow -Wait -PassThru -RedirectStandardError stderr2.txt -RedirectStandardOutput stdout2.txt
            } catch {
                Write-Log ("Start-Process (PEM) threw: " + $_.Exception.Message)
            }

            $stderr2 = ""
            $stdout2 = ""
            if (Test-Path stderr2.txt) { $stderr2 = (Get-Content stderr2.txt -Raw) -replace "`r","" }
            if (Test-Path stdout2.txt) { $stdout2 = (Get-Content stdout2.txt -Raw) -replace "`r","" }
            Write-Log ("OpenSSL PEM stdout: " + ($stdout2 -replace "`n"," | "))
            Write-Log ("OpenSSL PEM stderr: " + ($stderr2 -replace "`n"," | "))

            $exit2 = -1
            try { if ($proc2 -ne $null) { $exit2 = $proc2.ExitCode } } catch {}

            if ($exit2 -eq 0) {
                Write-Log "OpenSSL cms verification succeeded (PEM)."
                Remove-Item stderr.txt, stdout.txt, stderr2.txt, stdout2.txt -ErrorAction SilentlyContinue
                return $true
            }

            Write-Log ("OpenSSL verification failed (DER exit " + $exit1 + ", PEM exit " + $exit2 + ").")
            Remove-Item stderr.txt, stdout.txt, stderr2.txt, stdout2.txt -ErrorAction SilentlyContinue
        }
    } catch {
        Write-Log ("OpenSSL fallback attempt threw: " + $_.Exception.Message)
    }

    # 3) Best-effort: extract certs from p7s and try verify using them
    try {
        Write-Log "Attempting best-effort pkcs7 cert extraction and check..."
        $tmpCerts = Join-Path $env:TEMP ("extracted_p7s_certs_{0}.pem" -f ([guid]::NewGuid().ToString()))
        $openssl = "openssl"
        $opensslAvailable2 = $false
        try {
            & $openssl version > $null 2>&1
            if ($LASTEXITCODE -eq 0) { $opensslAvailable2 = $true }
        } catch { $opensslAvailable2 = $false }

        if ($opensslAvailable2) {
            try {
                & $openssl pkcs7 -in $SignaturePath -inform DER -print_certs -out $tmpCerts 2>$null
            } catch {
                Write-Log ("OpenSSL pkcs7 extraction threw: " + $_.Exception.Message)
            }

            if (Test-Path $tmpCerts) {
                Write-Log ("Extracted certs to " + $tmpCerts)
                $proc3 = $null
                try {
                    $proc3 = Start-Process -FilePath $openssl -ArgumentList @("cms","-verify","-in",$SignaturePath,"-inform","DER","-content",$ContentPath,"-CAfile",$tmpCerts,"-out","NUL","-binary") -NoNewWindow -Wait -PassThru -RedirectStandardError stderr3.txt -RedirectStandardOutput stdout3.txt
                } catch {
                    Write-Log ("Start-Process (extracted certs) threw: " + $_.Exception.Message)
                }

                $stderr3 = ""
                if (Test-Path stderr3.txt) { $stderr3 = (Get-Content stderr3.txt -Raw) -replace "`r","" }
                Write-Log ("OpenSSL extracted-certs stderr: " + ($stderr3 -replace "`n"," | "))

                $exit3 = -1
                try { if ($proc3 -ne $null) { $exit3 = $proc3.ExitCode } } catch {}

                if ($exit3 -eq 0) {
                    Write-Log "OpenSSL verify using extracted certs succeeded."
                    Remove-Item $tmpCerts, stderr3.txt, stdout3.txt -ErrorAction SilentlyContinue
                    return $true
                } else {
                    Write-Log ("OpenSSL verify using extracted certs failed (exit " + $exit3 + ").")
                }
                Remove-Item $tmpCerts -ErrorAction SilentlyContinue
            } else {
                Write-Log "No certs extracted from p7s."
            }
        } else {
            Write-Log "OpenSSL not available for cert extraction."
        }
    } catch {
        Write-Log ("Best-effort extraction attempt threw: " + $_.Exception.Message)
    }

    Write-Log "PKCS#7 verification: all methods failed."
    return $false
}

# -------------------------
# Build email body (unchanged)
# -------------------------
function Build-EmailBody {
    param(
        [string]$ExhibitRoot,
        [string]$ExhibitId,
        [string]$SealedZipName,
        [string]$SealedSha,
        [string]$ManifestZipName,
        [string]$ManifestSha
    )

@"
To: enforcement@rcj.gov.uk
Subject: RCJ Exhibit Delivery — Exhibit $ExhibitId — Manifest and Secure Link, FJ 124/25

IN THE HIGH COURT OF JUSTICE
KING'S BENCH DIVISION
CLAIM NO: FJ 124/25

EXHIBIT $ExhibitId

Attached: $ManifestZipName
Sealed container: $SealedZipName
Sealed SHA256: $SealedSha
Manifest SHA256: $ManifestSha

Google Drive link for sealed materials:
- [INSERT GOOGLE DRIVE LINK HERE]

Verification:

The sealed exhibit can be verified using the official verification tool:

RCJ.ExhibitVerifier_Clerk.exe
Available from: https://drive.google.com/file/d/1Xevyp1EewqzxtQY3m9s4f7fZqLowfpHw/view?usp=sharing

1) Download the EXE
2) Run RCJ.ExhibitVerifier_Clerk.exe
3) When prompted, browse to the exhibit folder (the folder containing the sealed-*.zip, manifest ZIP, and DELIVERY_INDEX.csv) and select it
4) Click "Verify Exhibit"

If all checks pass, the tool will display:

PKCS#7 signature OK
SHA256 OK
Manifest OK
DELIVERY_INDEX.csv OK
Verification complete.

If the verification tool cannot be run on your workstation, please feel welcome to get in contact about manual verification.

Yours faithfully,
Thomas Campbell
"@
}

# -------------------------
# Browse button: COM Shell.Application folder picker (defensive)
# -------------------------
$BtnBrowse.Add_Click({
    try {
        # Create and store COM object in global so we can release it on close
        try {
            $shell = New-Object -ComObject Shell.Application
            $global:ShellCom = $shell
        } catch {
            Write-Log ("COM Shell.Application not available: {0}" -f $_.Exception.Message)
            $shell = $null
            $global:ShellCom = $null
        }

        if ($shell) {
            $folder = $shell.BrowseForFolder(0, "Select exhibit folder (contains sealed-*.zip etc.)", 0)
            if ($folder -ne $null) {
                try { $path = $folder.Self.Path } catch { $path = $null }
                if ($path) {
                    $FolderBox.Text = $path
                    $ReportBox.Clear()
                    Write-Log ("Selected folder: {0}" -f $path)
                } else { Write-Log "Browse returned no path." }
            } else { Write-Log "Browse cancelled." }
        } else {
            Write-Log "Browse not available; paste or drag the folder path into the box."
        }
    } catch {
        Write-Log ("Browse handler error: {0}" -f $_.Exception.Message)
    }
})

# -------------------------
# Verify button (defensive)
# -------------------------
$BtnVerify.Add_Click({
    try {
        $ReportBox.Clear()
        $root = $FolderBox.Text
        if (-not $root -or -not (Test-Path $root)) {
            Write-Log "Error: Please select a valid exhibit folder."
            return
        }

        $ExhibitId = Split-Path $root -Leaf
        Write-Log ("Starting verification...") 
        Write-Log ("Exhibit ID: {0}" -f $ExhibitId)

        $sealedZip    = Get-ChildItem -Path $root -Filter 'sealed-*.zip' -File -ErrorAction SilentlyContinue | Select-Object -First 1
        $sigFile      = Get-ChildItem -Path $root -Filter 'sealed-*.zip.p7s' -File -ErrorAction SilentlyContinue | Select-Object -First 1
        $manifestZip  = Get-ChildItem -Path $root -Filter 'RCJ-Delivery-*-manifest.zip' -File -ErrorAction SilentlyContinue | Select-Object -First 1
        $sealedShaTxt = Join-Path $root 'sealed_sha256.txt'
        $indexFile    = Join-Path $root 'DELIVERY_INDEX.csv'

        if (-not $sealedZip)   { Write-Log "Error: No sealed-*.zip found."; return }
        if (-not $sigFile)     { Write-Log "Error: No sealed-*.zip.p7s found."; return }
        if (-not $manifestZip) { Write-Log "Error: No RCJ-Delivery-*-manifest.zip found."; return }

        Write-Log ("Found sealed ZIP: {0}" -f $sealedZip.Name)
        Write-Log ("Found signature:  {0}" -f $sigFile.Name)
        Write-Log ("Found manifest ZIP: {0}" -f $manifestZip.Name)

        # sealed SHA256
        $sealedSha = Get-Sha256 $sealedZip.FullName
        if ($sealedSha) {
            Write-Log ("sealed computed: {0}" -f $sealedSha)
        } else {
            Write-Log "Error computing sealed SHA256."
        }

        if (Test-Path $sealedShaTxt) {
            try {
                $expectedSealed = (Get-Content -LiteralPath $sealedShaTxt -ErrorAction Stop | Select-Object -First 1).Trim()
                Write-Log ("sealed expected: {0}" -f $expectedSealed)
                if ($sealedSha -and $sealedSha -eq $expectedSealed) {
                    Write-Log "sealed SHA256 OK (matches sealed_sha256.txt)"
                } else {
                    Write-Log "sealed SHA256 MISMATCH (does not match sealed_sha256.txt)"
                }
            } catch {
                Write-Log ("Error reading sealed_sha256.txt: {0}" -f $_.Exception.Message)
            }
        } else {
            Write-Log "Warning: sealed_sha256.txt not found."
        }

        # PKCS#7
        $signerCer = Join-Path $root 'signer.cer'
        if (Test-Path $signerCer) {
            $ok = Test-Pkcs7Signature -ContentPath $sealedZip.FullName -SignaturePath $sigFile.FullName -OptionalSignerCertPath $signerCer
        } else {
            $ok = Test-Pkcs7Signature -ContentPath $sealedZip.FullName -SignaturePath $sigFile.FullName
        }
        if ($ok) { Write-Log "PKCS#7 signature OK" } else { Write-Log "PKCS#7 signature FAIL" }

        # manifest ZIP hash
        $manifestSha = Get-Sha256 $manifestZip.FullName
        if ($manifestSha) {
            Write-Log ("manifest hash: {0}" -f $manifestSha)
        } else {
            Write-Log "Manifest hash error."
        }

        # index hash (optional)
        if (Test-Path $indexFile) {
            $indexSha = Get-Sha256 $indexFile
            if ($indexSha) {
                Write-Log ("DELIVERY_INDEX.csv hash: {0}" -f $indexSha)
            } else {
                Write-Log "Index hash error."
            }
        } else {
            Write-Log "Warning: DELIVERY_INDEX.csv not found."
        }

        Write-Log "Verification complete."

        # Store data on window for email buttons
        $window.Tag = [PSCustomObject]@{
            ExhibitRoot     = $root
            ExhibitId       = $ExhibitId
            SealedZipName   = $sealedZip.Name
            SealedSha       = $sealedSha
            ManifestZipName = $manifestZip.Name
            ManifestSha     = $manifestSha
        }
    } catch {
        Write-Log ("Verification error: {0}: {1}" -f $_.Exception.GetType().FullName, $_.Exception.Message)
        Write-Log $_.Exception.StackTrace
    }
})

# -------------------------
# Copy Email button (defensive)
# -------------------------
$BtnCopyEmail.Add_Click({
    try {
        $ctx = $window.Tag
        if (-not $ctx) {
            Write-Log "Error: No prepared email. Run Verify first."
            return
        }

        $body = Build-EmailBody -ExhibitRoot $ctx.ExhibitRoot `
                                -ExhibitId $ctx.ExhibitId `
                                -SealedZipName $ctx.SealedZipName `
                                -SealedSha $ctx.SealedSha `
                                -ManifestZipName $ctx.ManifestZipName `
                                -ManifestSha $ctx.ManifestSha

        try {
            [System.Windows.Clipboard]::SetText($body)
            Write-Log "Email body copied to clipboard."
        } catch {
            try {
                Add-Type -AssemblyName System.Windows.Forms
                [System.Windows.Forms.Clipboard]::SetText($body)
                Write-Log "Email body copied to clipboard (WinForms fallback)."
            } catch {
                Write-Log ("Failed to copy to clipboard: {0}" -f $_.Exception.Message)
            }
        }
    } catch {
        Write-Log ("Copy Email handler error: {0}" -f $_.Exception.Message)
    }
})

# -------------------------
# Open Mail Client button
# -------------------------
$BtnOpenMail.Add_Click({
    try {
        $ctx = $window.Tag
        if (-not $ctx) {
            Write-Log "Error: No prepared email. Run Verify first."
            return
        }

        $subject = "RCJ Exhibit Delivery — Exhibit $($ctx.ExhibitId) — Manifest and Secure Link"
        $body    = Build-EmailBody -ExhibitRoot $ctx.ExhibitRoot `
                                   -ExhibitId $ctx.ExhibitId `
                                   -SealedZipName $ctx.SealedZipName `
                                   -SealedSha $ctx.SealedSha `
                                   -ManifestZipName $ctx.ManifestZipName `
                                   -ManifestSha $ctx.ManifestSha

        $subjectEnc = [System.Uri]::EscapeDataString($subject)
        $bodyEnc    = [System.Uri]::EscapeDataString($body)

        $mailto = "mailto:enforcement@rcj.gov.uk?subject=$subjectEnc&body=$bodyEnc"
        Start-Process $mailto
        Write-Log "Opened default mail client with prepared email."
    } catch {
        Write-Log ("Open Mail handler error: {0}" -f $_.Exception.Message)
    }
})

# -------------------------
# Close button
# -------------------------
$BtnClose.Add_Click({
    try { $window.Close() } catch { Write-Log ("Close handler error: {0}" -f $_.Exception.Message) }
})

# -------------------------
# Ensure clean shutdown and suppress any post-close dialogs
# -------------------------
try {
    try { [System.Windows.Application]::Current.ShutdownMode = 'OnMainWindowClose' } catch {}

    $window.Add_Closing({
        param($sender, $e)
        try {
            $e.Cancel = $false
        } catch {
            FileLog ("Window Closing handler error: {0}" -f $_.Exception.Message)
        }
    })

    $window.Add_Closed({
        param($sender, $e)
        try {
            FileLog "Window closed; performing final cleanup."

            # Release COM Shell.Application if created
            try {
                if ($global:ShellCom -ne $null) {
                    try {
                        [System.Runtime.InteropServices.Marshal]::ReleaseComObject($global:ShellCom) | Out-Null
                    } catch {}
                    try { $global:ShellCom = $null } catch {}
                    FileLog "Released Shell.Application COM object."
                }
            } catch {
                FileLog ("Error releasing COM object: {0}" -f $_.Exception.Message)
            }

            # Force garbage collection and wait for finalizers
            try { [GC]::Collect(); [GC]::WaitForPendingFinalizers() } catch {}

            # Attempt to shutdown dispatcher to avoid late UI exceptions
            try { [System.Windows.Threading.Dispatcher]::CurrentDispatcher.InvokeShutdown() } catch {}
        } catch {
            FileLog ("Window Closed handler error: {0}" -f $_.Exception.Message)
        } finally {
            # Force process exit to guarantee no late modal dialogs from finalizers
            try { [System.Environment]::Exit(0) } catch {}
        }
    })
} catch {
    FileLog ("Setup shutdown handlers failed: {0}" -f $_.Exception.Message)
}

# -------------------------
# Show GUI (top-level catch)
# -------------------------
try {
    $window.ShowDialog() | Out-Null
} catch {
    FileLog ("Fatal UI error: {0}: {1}" -f $_.Exception.GetType().FullName, $_.Exception.Message)
    FileLog $_.Exception.StackTrace
    # No message boxes shown; user can inspect $LogFile
}

# SIG # Begin signature block
# MIIcFAYJKoZIhvcNAQcCoIIcBTCCHAECAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDr/Bu1oDcZ/GR9
# Dj60ZJI+iibIpj88UzYvEzuYQvvDEKCCFlYwggMYMIICAKADAgECAhATDNXImNAO
# gkNGajdF5MyQMA0GCSqGSIb3DQEBBQUAMCQxIjAgBgNVBAMMGVRvbSBUZXN0IENv
# ZGUgU2lnbmluZyBDU1AwHhcNMjYwMzA3MTIxMTU3WhcNMjcwMzA3MTIzMTU3WjAk
# MSIwIAYDVQQDDBlUb20gVGVzdCBDb2RlIFNpZ25pbmcgQ1NQMIIBIjANBgkqhkiG
# 9w0BAQEFAAOCAQ8AMIIBCgKCAQEAt+QiSqflQ1GZ7VFY41JdiICCJv5y8tY9hRIP
# /0rvtEmv8V0O6d3WGOcdikmEwWEsV6dfL495oV365S5tfz/z/hS3J4BtA4fQfbRG
# LOYGXQLxlI0zIvK4hHlhyYhJwVP0MXN7418lG0QmDA98fx7MgDTHZayDYHilgqKm
# EHhHMSQLarABODyYOdoXpAcxLcmWD/Wk6+5DpEklFWb+vsNA8s6uc3A3alIdhxSb
# Kqcr7k5rty7mRDAObVmOsfXy9W4ZlQdghWQu4Pr8K2x93lbdjNFrcVMC4NprEoyv
# nDrcIqVN1pGfDGWXQPCaxoFjhw/PYRzbdKuiRDoCUueXcVCT2QIDAQABo0YwRDAO
# BgNVHQ8BAf8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFMuY
# d6tE3bNaqnSdwNl0VjaO/28GMA0GCSqGSIb3DQEBBQUAA4IBAQBDU+Fp1E0CWeTy
# EsEOXbJEL0mrcxxMktA1rXJbdTi1VvqL0Eh3JnlYm28bPLZw/7mT+OWclT+nDsPp
# jYRCLpTsAIZDfnVHPM53sxYlSz7qEKGG45n0UJiyh9P4cIbvJpSLLu65A5SWvu+W
# 0k79POO5TrOhYpxaBo5TBQ1GhSlPm81WB8wlVDC8a4lePFsbMBVOiy9bfTtTOTEJ
# x7V708NTFA1EpYduBec7WywRZKJLmXtsCpJz+QmTSL7SzdQ9T/r75B3IiGZPDcLr
# PIWH52XuboKeZIxGy9N63m8LPUFod7vZ7+E7dTNiBA/RDh8vi9Fs3LWkylB+JdW1
# QVpFTOqyMIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0B
# AQwFADBlMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYD
# VQQLExB3d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVk
# IElEIFJvb3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQsw
# CQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cu
# ZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQw
# ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz
# 7MKnJS7JIT3yithZwuEppz1Yq3aaza57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS
# 5F/WBTxSD1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7
# bXHiLQwb7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfI
# SKhmV1efVFiODCu3T6cw2Vbuyntd463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jH
# trHEtWoYOAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14
# Ztk6MUSaM0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2
# h4mXaXpI8OCiEhtmmnTK3kse5w5jrubU75KSOp493ADkRSWJtppEGSt+wJS00mFt
# 6zPZxd9LBADMfRyVw4/3IbKyEbe7f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPR
# iQfhvbfmQ6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ER
# ElvlEFDrMcXKchYiCd98THU/Y+whX8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4K
# Jpn15GkvmB0t9dmpsh3lGwIDAQABo4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAd
# BgNVHQ4EFgQU7NfjgtJxXWRM3y5nP+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SS
# y4IxLVGLp6chnfNtyA8wDgYDVR0PAQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAC
# hjdodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURS
# b290Q0EuY3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0
# LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRV
# HSAAMA0GCSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyh
# hyzshV6pGrsi+IcaaVQi7aSId229GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO
# 0Cre+i1Wz/n096wwepqLsl7Uz9FDRJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo
# 8L8vC6bp8jQ87PcDx4eo0kxAGTVGamlUsLihVo7spNU96LHc/RzY9HdaXFSMb++h
# UD38dglohJ9vytsgjTVgHAIDyyCwrFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5x
# aiNrIv8SuFQtJ37YOtnwtoeW/VvRXKwYw02fc7cBqZ9Xql4o4rmUMIIGtDCCBJyg
# AwIBAgIQDcesVwX/IZkuQEMiDDpJhjANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjUw
# NTA3MDAwMDAwWhcNMzgwMTE0MjM1OTU5WjBpMQswCQYDVQQGEwJVUzEXMBUGA1UE
# ChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQg
# VGltZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2IDIwMjUgQ0ExMIICIjANBgkqhkiG
# 9w0BAQEFAAOCAg8AMIICCgKCAgEAtHgx0wqYQXK+PEbAHKx126NGaHS0URedTa2N
# DZS1mZaDLFTtQ2oRjzUXMmxCqvkbsDpz4aH+qbxeLho8I6jY3xL1IusLopuW2qft
# JYJaDNs1+JH7Z+QdSKWM06qchUP+AbdJgMQB3h2DZ0Mal5kYp77jYMVQXSZH++0t
# rj6Ao+xh/AS7sQRuQL37QXbDhAktVJMQbzIBHYJBYgzWIjk8eDrYhXDEpKk7RdoX
# 0M980EpLtlrNyHw0Xm+nt5pnYJU3Gmq6bNMI1I7Gb5IBZK4ivbVCiZv7PNBYqHEp
# NVWC2ZQ8BbfnFRQVESYOszFI2Wv82wnJRfN20VRS3hpLgIR4hjzL0hpoYGk81coW
# J+KdPvMvaB0WkE/2qHxJ0ucS638ZxqU14lDnki7CcoKCz6eum5A19WZQHkqUJfdk
# DjHkccpL6uoG8pbF0LJAQQZxst7VvwDDjAmSFTUms+wV/FbWBqi7fTJnjq3hj0Xb
# Qcd8hjj/q8d6ylgxCZSKi17yVp2NL+cnT6Toy+rN+nM8M7LnLqCrO2JP3oW//1sf
# uZDKiDEb1AQ8es9Xr/u6bDTnYCTKIsDq1BtmXUqEG1NqzJKS4kOmxkYp2WyODi7v
# QTCBZtVFJfVZ3j7OgWmnhFr4yUozZtqgPrHRVHhGNKlYzyjlroPxul+bgIspzOwb
# tmsgY1MCAwEAAaOCAV0wggFZMBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYE
# FO9vU0rp5AZ8esrikFb2L9RJ7MtOMB8GA1UdIwQYMBaAFOzX44LScV1kTN8uZz/n
# upiuHA9PMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcDCDB3Bggr
# BgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBBBggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYDVR0fBDwwOjA4oDagNIYyaHR0cDovL2Ny
# bDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0g
# BBkwFzAIBgZngQwBBAIwCwYJYIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQAX
# zvsWgBz+Bz0RdnEwvb4LyLU0pn/N0IfFiBowf0/Dm1wGc/Do7oVMY2mhXZXjDNJQ
# a8j00DNqhCT3t+s8G0iP5kvN2n7Jd2E4/iEIUBO41P5F448rSYJ59Ib61eoalhnd
# 6ywFLerycvZTAz40y8S4F3/a+Z1jEMK/DMm/axFSgoR8n6c3nuZB9BfBwAQYK9FH
# aoq2e26MHvVY9gCDA/JYsq7pGdogP8HRtrYfctSLANEBfHU16r3J05qX3kId+ZOc
# zgj5kjatVB+NdADVZKON/gnZruMvNYY2o1f4MXRJDMdTSlOLh0HCn2cQLwQCqjFb
# qrXuvTPSegOOzr4EWj7PtspIHBldNE2K9i697cvaiIo2p61Ed2p8xMJb82Yosn0z
# 4y25xUbI7GIN/TpVfHIqQ6Ku/qjTY6hc3hsXMrS+U0yy+GWqAXam4ToWd2UQ1KYT
# 70kZjE4YtL8Pbzg0c1ugMZyZZd/BdHLiRu7hAWE6bTEm4XYRkA6Tl4KSFLFk43es
# aUeqGkH/wyW4N7OigizwJWeukcyIPbAvjSabnf7+Pu0VrFgoiovRDiyx3zEdmcif
# /sYQsfch28bZeUz2rtY/9TCA6TD8dC3JE3rYkrhLULy7Dc90G6e8BlqmyIjlgp2+
# VqsS9/wQD7yFylIz0scmbKvFoW2jNrbM1pD2T7m3XDCCBu0wggTVoAMCAQICEAhP
# 3DNPfkVO28MPj/mSGDUwDQYJKoZIhvcNAQELBQAwaTELMAkGA1UEBhMCVVMxFzAV
# BgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVk
# IEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2IFNIQTI1NiAyMDI1IENBMTAeFw0yNjA4
# MDUwMDAwMDBaFw0zNzExMDQyMzU5NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQK
# Ew5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgU0hBMjU2IFJTQTQw
# OTYgVGltZXN0YW1wIFJlc3BvbmRlciAyMDI2IDEwggIiMA0GCSqGSIb3DQEBAQUA
# A4ICDwAwggIKAoICAQC2e6byyf7NSvjUm0xls/04xjD4fAkOkbnGQi7+Wpx81iYx
# fzViaxSIctuH3KSl5YEYpMuFgGsA31N2D9ATMbfZdw5uaAhuWevQKhDdZIB4Nnqc
# fpfpWQXJiQnDdAElETC+bhSEvNLGbA8DtwUpFMQ4yyYQSPqomT92osQAv6hBi47A
# TZS6JfVWe6XxhF4jJZ3iSAuf2Cros1czRSmWRHqMv9AfGZvp8ygYElhudpQjtcPp
# woOl6QrZJUyV3iINvN4cO05prGV0fkjG426xDr2d3z9lcSIHkdvGPdGUrXdxfVbg
# OUVcp2/8ISEzwKPW++Wa+E2ujI91EZtukGWDJ/xZ27k3oHKEXBRGfRTqjOU+jE3b
# a/5++JSE/7oNHnjs5mekExYN96LV/mxUbCKJb8pBNY4r3uD7hEmk/M81XhVgwDA7
# aMzYC3LZBg9WY5BMmbSay5ecmtJuXaB/0nKWmQmVZeqTVDgsmzHP5MQuhAJkiWNu
# C9MmCg9TZHXbJ2/yLVSov9p16UDTLtT0+aa1vN71fHeu1qMLlLNB3WOB/ADCxr3S
# /1hxI92Z6jKgEED/btwIvbfuXkNNhg8MtDg43c4tMZae9FvqMOt/9PvmAxF9TNIs
# IFB8G6yb36ZJZGUL8N/pL971DyLXcK6HM5PYnH5X+eVtczhCgHCVQCF6XDAlPQID
# AQABo4IBlTCCAZEwDAYDVR0TAQH/BAIwADAdBgNVHQ4EFgQUFMljijAu1Er7bpTz
# 5uNAfvXszeIwHwYDVR0jBBgwFoAU729TSunkBnx6yuKQVvYv1Ensy04wDgYDVR0P
# AQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIGVBggrBgEFBQcBAQSB
# iDCBhTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMF0GCCsG
# AQUFBzAChlFodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVz
# dGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2U0hBMjU2MjAyNUNBMS5jcnQwXwYDVR0f
# BFgwVjBUoFKgUIZOaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1
# c3RlZEc0VGltZVN0YW1waW5nUlNBNDA5NlNIQTI1NjIwMjVDQTEuY3JsMCAGA1Ud
# IAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEA
# jcU6YR6dUgrfmawJgH59KECxa9Ji8sEi2g10CBDaMiqsaxWyW5cwlT/6ZF5sFzna
# zqVsoC85U9dqLOYqQwst+UQQoNlDHgKRLa3xoc+OReFreFhnTXSG0Vrd2E2CZqUf
# m+5a+He1MJ/h+tNLuA+0Zzhn/Fo+FDYAHWZHx4R79ZsfRFYe9UiXpXBDf6DkUo18
# 3Y38NYmR/XfDYf7YZ+oR9t3flbDwK+hgGMs0gNNp1w9Z2CyOyI5or/sSwomAuNQ0
# hWC9xoU4stD8aWsD7RkcmgVRs6vlIk3zPKQ+ylcheWkMlj+CoVRlFE55pv0ZWCaF
# t04lwP/rdGHE9qEVQZtyRE42ox7oNgC/r+Y4bSlZ3dw9K2x1xLtu6PkPKeLBFjzK
# igwfqm3Hm+k/+lnME8F5kPZTgiy2HLEHklpryqs6QHnPXrRNeIzkAMyylnRN8P0w
# mirS0WkU+ywpEWFZ4QNg+9xS43tTuW9x0eXh7NDc1P/sV+zWxHXKH8tFt1ncHdVz
# qrZaYPyYMLSn2TOXajveJW1L3joiQSPsWRGxkbDDW15jERFE4LvjnGu2O9zD1nLJ
# SMdlYZEikl4w2w+q4IN/R+TIe0H4ngCI1moJCTbevGH4punIxM1Uoi0nmX3ZK+Xb
# RT01uowE5ViXWHng0RgsmrX/EdYUo80r3TfMlkD0/YMxggUUMIIFEAIBATA4MCQx
# IjAgBgNVBAMMGVRvbSBUZXN0IENvZGUgU2lnbmluZyBDU1ACEBMM1ciY0A6CQ0Zq
# N0XkzJAwDQYJYIZIAWUDBAIBBQCggYQwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKA
# ADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYK
# KwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg/eSiAHpjWv9NCSj/VNLmvYpmZ9g1
# RNVVO5mcQNqFRhgwDQYJKoZIhvcNAQEBBQAEggEAgd2bHJB10/c6eIU1mxFZO/yI
# IlYjwVgjNx8sTrv5eWFvUFBrfQwQwBd5QElZue8YJHGDnVhSwuQnESwEw0FihRe0
# JNfX2Yzqvdp+/q9ZAzPOvHgTpcxtiGInJ9NZLkrrloIIWy0uZx3G/pSHOt6Uio3h
# k68GgWrIsRCajUmsIGTi2ui59DKYI1XoCdJNj1dd/gLHKB6uvGCJIMmbhfdZ5J2S
# IX+M7KPaBXmi3Y6dOvu+HWT/GsII8YkCjJUcLdF9Tgf2nMR8J3vJcKCxkDwJkUKM
# s03AXiopohlok9CCbIeQ6zA4zoAonkhQ2MZuBXWOZzhltna0m4+KCzZtwGCMIaGC
# AyYwggMiBgkqhkiG9w0BCQYxggMTMIIDDwIBATB9MGkxCzAJBgNVBAYTAlVTMRcw
# FQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3Rl
# ZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAyNSBDQTECEAhP3DNP
# fkVO28MPj/mSGDUwDQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZI
# hvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yNjA5MjIxMTIzMDZaMC8GCSqGSIb3DQEJ
# BDEiBCDw39aRgK5kiSQz+1GkZpa/Y24Mxt9ff5nz5/C+ChpFJzANBgkqhkiG9w0B
# AQEFAASCAgA0XsA+fSE0Cdax3IN091JUyuQLBgYu2K8W4tpIW0eJlWezqe1ZLLmG
# bZA05rTzmKmxvH9YrOlqZhcEV2c9z4GEMCuy/98/f7i/mm1FjFztCAhkZZWCVJgr
# 2EAJKCgXxmDJ3twP5XnVIr5Q+z6lt4T0NCYQv5TZ/tA4Xf5gPeFBqqTcw6OSFN2a
# rL418WVeWbyRAd9OQclMCp8AjeQgihcP9UX446BToZ5EXVw/kgb0j6vg25pWDnql
# XQsBTDzyckRBjzdNiTXMkYYjLADmS8EeMLfTlZvGNlJqVwY2TpdnOeKHqVAiv/Hi
# GMDsobFrfpm39SPkC5KehpqDjZn3sU0wkOJe1CzsTpBC5kx/7mrCrdl0ZeRkVskt
# IgLyK1FmfRk0r4XJVFQRrC7eHuhZQ29w6fNek6vsEOBTTPWHzqqvLi9uikrnwUWE
# zG1NQaUaKs7jmobd2rqIcdsqQf4MErXnil8x2kAdxGjgtipT1C3MUlb2bkq3zK/i
# Hy2RT6vvDQRJg6Yr8IemW9NkUELqkQm2066Rz8DHp84BJVLjgi8EzbCUnhFawzJF
# c3pzIJYQzNHNGOZ+mcujCkV2/Yv5MJsW0BZ7PQ5gQovwdNmOsYEmImIAeQoKCGBR
# 0/HbauPN/uGcWpZgyN6oE9DeqLpSAQUEcWIZn5GtKuTD+k+mWjDJ/g==
# SIG # End signature block
