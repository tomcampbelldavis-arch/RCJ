@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$f = Join-Path $PSScriptRoot 'RCJ.ExhibitVerifier_Clerk.ps1'; ^
   $s = Get-AuthenticodeSignature $f; ^
   if ($s.Status -ne 'Valid') { Write-Host 'Signature invalid: ' $s.Status; pause; exit 1 } ^
   if ($s.SignerCertificate.Thumbprint -ne '0FFFBD8B4BD85A5C7B643C242BB7E59FB97FA316') { Write-Host 'Signer mismatch. Aborting.'; pause; exit 1 } ^
   Write-Host 'Verified. Launching...'; Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File', (\"`\" + $f + \"`\" ) -Wait; Write-Host 'Done.'; pause"
